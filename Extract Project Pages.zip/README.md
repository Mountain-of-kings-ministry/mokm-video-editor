
  # Extract Project Pages

  This is a code bundle for Extract Project Pages. The original project is available at https://www.figma.com/design/zIR9seOWrXX5epb92E90y2/Extract-Project-Pages.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  