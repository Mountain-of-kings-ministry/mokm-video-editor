import { useState } from 'react';
import { MediaPage } from './components/MediaPage';
import { EditPage } from './components/EditPage';
import { NodeGraphPage } from './components/NodeGraphPage';
import { ColorGradingPage } from './components/ColorGradingPage';
import { AudioMixingPage } from './components/AudioMixingPage';
import { ExportPage } from './components/ExportPage';
import { ProjectSettings } from './components/ProjectSettings';
import { Preferences } from './components/Preferences';
import { ProxyManager } from './components/ProxyManager';
import { PluginManager } from './components/PluginManager';
import { KeyboardMapper } from './components/KeyboardMapper';
import { Film, Scissors, GitBranch, Palette, Volume2, Upload, Settings, Sliders, Database, Puzzle, Keyboard } from 'lucide-react';

type PageType = 'media' | 'edit' | 'nodes' | 'color' | 'audio' | 'export' | 'settings' | 'preferences' | 'proxy' | 'plugins' | 'shortcuts';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('edit');

  const navItems = [
    { id: 'media' as PageType, icon: Film, label: 'Media' },
    { id: 'edit' as PageType, icon: Scissors, label: 'Edit' },
    { id: 'nodes' as PageType, icon: GitBranch, label: 'Nodes' },
    { id: 'color' as PageType, icon: Palette, label: 'Color' },
    { id: 'audio' as PageType, icon: Volume2, label: 'Audio' },
    { id: 'export' as PageType, icon: Upload, label: 'Export' },
  ];

  const systemItems = [
    { id: 'settings' as PageType, icon: Settings, label: 'Project Settings' },
    { id: 'preferences' as PageType, icon: Sliders, label: 'Preferences' },
    { id: 'proxy' as PageType, icon: Database, label: 'Proxy Manager' },
    { id: 'plugins' as PageType, icon: Puzzle, label: 'Plugins' },
    { id: 'shortcuts' as PageType, icon: Keyboard, label: 'Shortcuts' },
  ];

  const renderPage = () => {
    switch (currentPage) {
      case 'media': return <MediaPage />;
      case 'edit': return <EditPage />;
      case 'nodes': return <NodeGraphPage />;
      case 'color': return <ColorGradingPage />;
      case 'audio': return <AudioMixingPage />;
      case 'export': return <ExportPage />;
      case 'settings': return <ProjectSettings />;
      case 'preferences': return <Preferences />;
      case 'proxy': return <ProxyManager />;
      case 'plugins': return <PluginManager />;
      case 'shortcuts': return <KeyboardMapper />;
      default: return <EditPage />;
    }
  };

  return (
    <div className="size-full flex bg-[#1a1a1a] text-gray-100">
      {/* Sidebar Navigation */}
      <div className="w-16 bg-[#0f0f0f] border-r border-gray-800 flex flex-col">
        {/* Logo */}
        <div className="h-16 flex items-center justify-center border-b border-gray-800">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg" />
        </div>

        {/* Main Nav */}
        <div className="flex-1 py-4 space-y-1">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              className={`w-full h-12 flex items-center justify-center transition-colors ${
                currentPage === item.id
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
              title={item.label}
            >
              <item.icon size={20} />
            </button>
          ))}
        </div>

        {/* System Nav */}
        <div className="py-4 space-y-1 border-t border-gray-800">
          {systemItems.map(item => (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              className={`w-full h-12 flex items-center justify-center transition-colors ${
                currentPage === item.id
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
              title={item.label}
            >
              <item.icon size={20} />
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {renderPage()}
      </div>
    </div>
  );
}