import { useState } from 'react';
import { Search, Plus, ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';

interface Node {
  id: string;
  type: string;
  label: string;
  x: number;
  y: number;
  inputs: number;
  outputs: number;
  color: string;
}

export function NodeGraphPage() {
  const [nodes] = useState<Node[]>([
    { id: '1', type: 'Media', label: 'Interview.mp4', x: 100, y: 200, inputs: 0, outputs: 1, color: 'blue' },
    { id: '2', type: 'Transform', label: 'Scale', x: 300, y: 180, inputs: 1, outputs: 1, color: 'purple' },
    { id: '3', type: 'Color', label: 'Color Correct', x: 300, y: 280, inputs: 1, outputs: 1, color: 'green' },
    { id: '4', type: 'Merge', label: 'Merge', x: 500, y: 230, inputs: 2, outputs: 1, color: 'orange' },
    { id: '5', type: 'Media', label: 'Logo.png', x: 100, y: 350, inputs: 0, outputs: 1, color: 'blue' },
    { id: '6', type: 'Output', label: 'Viewer', x: 700, y: 230, inputs: 1, outputs: 0, color: 'red' },
  ]);

  const nodeTypes = [
    { category: 'Input', items: ['Media In', 'Color Generator', 'Text', 'Noise'] },
    { category: 'Transform', items: ['Scale', 'Rotate', 'Position', 'Crop'] },
    { category: 'Color', items: ['Color Correct', 'Curves', 'HSL', 'LUT'] },
    { category: 'Filter', items: ['Blur', 'Sharpen', 'Glow', 'Denoise'] },
    { category: 'Composite', items: ['Merge', 'Alpha Over', 'Keyer', 'Matte'] },
    { category: 'Output', items: ['Viewer', 'Export'] },
  ];

  const getNodeColor = (color: string) => {
    const colors: Record<string, string> = {
      blue: 'bg-blue-600 border-blue-500',
      purple: 'bg-purple-600 border-purple-500',
      green: 'bg-green-600 border-green-500',
      orange: 'bg-orange-600 border-orange-500',
      red: 'bg-red-600 border-red-500',
    };
    return colors[color] || 'bg-gray-600 border-gray-500';
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Node Library */}
      <div className="w-64 bg-[#0f0f0f] border-r border-gray-800 flex flex-col">
        <div className="p-3 border-b border-gray-800">
          <h3 className="font-semibold mb-3">Node Library</h3>
          <div className="relative">
            <Search size={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              placeholder="Search nodes..."
              className="w-full pl-8 pr-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>
        <div className="flex-1 overflow-auto p-3 space-y-4">
          {nodeTypes.map(category => (
            <div key={category.category}>
              <div className="text-xs font-semibold text-gray-500 mb-2">{category.category}</div>
              <div className="space-y-1">
                {category.items.map(item => (
                  <div
                    key={item}
                    className="px-3 py-2 bg-[#1a1a1a] hover:bg-gray-800 rounded text-sm cursor-pointer border border-transparent hover:border-gray-700"
                  >
                    {item}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Node Canvas */}
      <div className="flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="h-12 bg-[#0f0f0f] border-b border-gray-800 flex items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-sm flex items-center gap-2">
              <Plus size={14} />
              Add Node
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-1.5 hover:bg-gray-800 rounded">
              <ZoomOut size={16} />
            </button>
            <span className="text-sm font-mono">100%</span>
            <button className="p-1.5 hover:bg-gray-800 rounded">
              <ZoomIn size={16} />
            </button>
            <button className="p-1.5 hover:bg-gray-800 rounded ml-2">
              <Maximize2 size={16} />
            </button>
          </div>
        </div>

        {/* Canvas */}
        <div className="flex-1 relative bg-[#1a1a1a] overflow-hidden"
          style={{
            backgroundImage: 'radial-gradient(circle, #2a2a2a 1px, transparent 1px)',
            backgroundSize: '20px 20px'
          }}
        >
          {/* Connections */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            <path d="M 180 215 Q 240 215, 300 195" stroke="#4ade80" strokeWidth="2" fill="none" />
            <path d="M 180 215 Q 240 215, 300 295" stroke="#4ade80" strokeWidth="2" fill="none" />
            <path d="M 380 195 L 500 245" stroke="#8b5cf6" strokeWidth="2" fill="none" />
            <path d="M 380 295 L 500 245" stroke="#22c55e" strokeWidth="2" fill="none" />
            <path d="M 180 365 L 240 365 Q 300 365, 320 320" stroke="#4ade80" strokeWidth="2" fill="none" />
            <path d="M 580 245 L 700 245" stroke="#f97316" strokeWidth="2" fill="none" />
          </svg>

          {/* Nodes */}
          {nodes.map(node => (
            <div
              key={node.id}
              className={`absolute ${getNodeColor(node.color)} border rounded-lg shadow-lg cursor-move`}
              style={{ left: node.x, top: node.y, width: 160 }}
            >
              <div className="px-3 py-2 border-b border-white/20">
                <div className="text-xs text-white/60">{node.type}</div>
                <div className="text-sm font-medium">{node.label}</div>
              </div>
              <div className="relative py-3">
                {/* Input connectors */}
                {Array.from({ length: node.inputs }).map((_, i) => (
                  <div
                    key={`in-${i}`}
                    className="absolute left-0 w-3 h-3 bg-gray-300 border-2 border-white rounded-full -translate-x-1/2 cursor-pointer hover:bg-white"
                    style={{ top: `${30 + i * 20}px` }}
                  />
                ))}
                {/* Output connectors */}
                {Array.from({ length: node.outputs }).map((_, i) => (
                  <div
                    key={`out-${i}`}
                    className="absolute right-0 w-3 h-3 bg-gray-300 border-2 border-white rounded-full translate-x-1/2 cursor-pointer hover:bg-white"
                    style={{ top: `${30 + i * 20}px` }}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Mini-map */}
        <div className="absolute bottom-4 right-4 w-48 h-32 bg-black/50 backdrop-blur-sm border border-gray-700 rounded">
          <div className="w-full h-full p-2">
            <div className="w-full h-full border border-blue-500/50 relative">
              {nodes.map(node => (
                <div
                  key={node.id}
                  className="absolute w-2 h-2 bg-blue-500 rounded-sm"
                  style={{
                    left: `${(node.x / 800) * 100}%`,
                    top: `${(node.y / 600) * 100}%`
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Node Inspector */}
      <div className="w-72 bg-[#0f0f0f] border-l border-gray-800 overflow-auto">
        <div className="p-4">
          <h3 className="font-semibold mb-4">Node Properties</h3>
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-500 block mb-1">Node Name</label>
              <input
                type="text"
                defaultValue="Color Correct"
                className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Exposure</label>
              <input type="range" min="-2" max="2" step="0.1" defaultValue="0" className="w-full" />
              <div className="text-xs text-right text-gray-500">0.0</div>
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Contrast</label>
              <input type="range" min="0" max="2" step="0.1" defaultValue="1" className="w-full" />
              <div className="text-xs text-right text-gray-500">1.0</div>
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Saturation</label>
              <input type="range" min="0" max="2" step="0.1" defaultValue="1" className="w-full" />
              <div className="text-xs text-right text-gray-500">1.0</div>
            </div>
            <div className="pt-4 border-t border-gray-800">
              <div className="text-xs text-gray-500 mb-2">Cache Status</div>
              <div className="px-3 py-2 bg-green-600/20 border border-green-600/30 rounded text-sm text-green-400">
                Cached (32 frames)
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}