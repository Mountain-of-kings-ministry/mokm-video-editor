import { Volume2, Plus } from 'lucide-react';

export function AudioMixingPage() {
  const tracks = [
    { id: 1, name: 'Music Track', color: 'orange', level: -12, pan: 0 },
    { id: 2, name: 'Dialog', color: 'teal', level: -6, pan: 0 },
    { id: 3, name: 'SFX', color: 'purple', level: -18, pan: 20 },
    { id: 4, name: 'Ambience', color: 'green', level: -24, pan: -15 },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Toolbar */}
      <div className="h-12 bg-[#0f0f0f] border-b border-gray-800 flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <h2 className="font-semibold">Audio Mixer</h2>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-gray-500">Sample Rate:</span>
            <span>48 kHz</span>
            <span className="text-gray-500 ml-4">Bit Depth:</span>
            <span>24-bit</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm">Reset All</button>
          <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-sm flex items-center gap-2">
            <Plus size={14} />
            Add Track
          </button>
        </div>
      </div>

      {/* Mixer Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Mixer Faders */}
        <div className="flex-1 flex justify-center items-stretch gap-4 p-6 bg-[#1a1a1a] overflow-auto">
          {tracks.map(track => (
            <div key={track.id} className="w-32 flex flex-col bg-[#0f0f0f] rounded-lg border border-gray-800">
              {/* Track Header */}
              <div className="p-3 border-b border-gray-800">
                <div className={`text-xs font-medium text-${track.color}-400 mb-1`}>{track.name}</div>
                <div className="flex items-center gap-1">
                  <button className="px-1.5 py-0.5 text-xs bg-gray-800 hover:bg-gray-700 rounded">M</button>
                  <button className="px-1.5 py-0.5 text-xs bg-gray-800 hover:bg-gray-700 rounded">S</button>
                  <button className="px-1.5 py-0.5 text-xs bg-yellow-600 hover:bg-yellow-700 rounded">R</button>
                </div>
              </div>

              {/* Meters */}
              <div className="flex-1 flex gap-1 p-3 items-end justify-center">
                <div className="w-3 h-full bg-gray-800 rounded-sm relative overflow-hidden">
                  <div
                    className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-green-500 via-yellow-500 to-red-500"
                    style={{ height: `${Math.random() * 80 + 10}%` }}
                  />
                </div>
                <div className="w-3 h-full bg-gray-800 rounded-sm relative overflow-hidden">
                  <div
                    className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-green-500 via-yellow-500 to-red-500"
                    style={{ height: `${Math.random() * 80 + 10}%` }}
                  />
                </div>
              </div>

              {/* Fader */}
              <div className="p-3 flex flex-col items-center">
                <input
                  type="range"
                  min="-60"
                  max="12"
                  defaultValue={track.level}
                  className="h-48 writing-mode-vertical-lr appearance-none bg-transparent [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-8 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded [&::-webkit-slider-thumb]:bg-blue-600 [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-runnable-track]:bg-gray-700 [&::-webkit-slider-runnable-track]:h-1 [&::-webkit-slider-runnable-track]:rounded"
                  style={{ writingMode: 'bt-lr' }}
                />
                <div className="mt-2 text-xs font-mono text-gray-400">{track.level} dB</div>
              </div>

              {/* Pan Control */}
              <div className="p-3 border-t border-gray-800">
                <div className="text-xs text-gray-500 mb-2 text-center">Pan</div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  defaultValue={track.pan}
                  className="w-full"
                />
                <div className="text-xs text-center font-mono text-gray-400 mt-1">
                  {track.pan > 0 ? `R${track.pan}` : track.pan < 0 ? `L${Math.abs(track.pan)}` : 'C'}
                </div>
              </div>
            </div>
          ))}

          {/* Master Fader */}
          <div className="w-40 flex flex-col bg-gradient-to-b from-blue-900/20 to-blue-900/10 rounded-lg border-2 border-blue-800">
            <div className="p-3 border-b border-blue-800">
              <div className="text-sm font-bold text-blue-400 mb-1">Master</div>
              <div className="flex items-center gap-1">
                <Volume2 size={14} className="text-blue-400" />
              </div>
            </div>

            <div className="flex-1 flex gap-2 p-4 items-end justify-center">
              <div className="w-4 h-full bg-gray-800 rounded-sm relative overflow-hidden">
                <div className="absolute bottom-0 left-0 right-0 h-4/5 bg-gradient-to-t from-green-500 via-yellow-500 to-red-500" />
              </div>
              <div className="w-4 h-full bg-gray-800 rounded-sm relative overflow-hidden">
                <div className="absolute bottom-0 left-0 right-0 h-3/4 bg-gradient-to-t from-green-500 via-yellow-500 to-red-500" />
              </div>
            </div>

            <div className="p-4 flex flex-col items-center">
              <input
                type="range"
                min="-60"
                max="12"
                defaultValue="0"
                className="h-48 writing-mode-vertical-lr appearance-none bg-transparent [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-10 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded [&::-webkit-slider-thumb]:bg-blue-600 [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-runnable-track]:bg-gray-700 [&::-webkit-slider-runnable-track]:h-2 [&::-webkit-slider-runnable-track]:rounded"
                style={{ writingMode: 'bt-lr' }}
              />
              <div className="mt-3 text-sm font-mono text-blue-400">0.0 dB</div>
            </div>

            <div className="p-3 border-t border-blue-800 text-center">
              <div className="text-xs text-gray-500 mb-2">Peak</div>
              <div className="text-sm font-mono text-green-400">-3.2 dB</div>
            </div>
          </div>
        </div>

        {/* Track Inspector */}
        <div className="w-80 bg-[#0f0f0f] border-l border-gray-800 overflow-auto">
          <div className="p-4">
            <h3 className="font-semibold mb-4">Track Inspector</h3>

            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-500 block mb-2">Track Name</label>
                <input
                  type="text"
                  defaultValue="Dialog"
                  className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="pt-4 border-t border-gray-800">
                <div className="text-sm font-medium mb-3">Effects Chain</div>
                <div className="space-y-2">
                  <div className="px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Noise Reduction</span>
                    </div>
                    <button className="text-xs text-gray-500 hover:text-white">Edit</button>
                  </div>
                  <div className="px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">EQ</span>
                    </div>
                    <button className="text-xs text-gray-500 hover:text-white">Edit</button>
                  </div>
                  <div className="px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <input type="checkbox" className="rounded" />
                      <span className="text-sm">Compressor</span>
                    </div>
                    <button className="text-xs text-gray-500 hover:text-white">Edit</button>
                  </div>
                  <button className="w-full px-3 py-2 border border-dashed border-gray-700 rounded text-sm text-gray-500 hover:text-white hover:border-gray-600">
                    + Add Effect
                  </button>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-800">
                <div className="text-sm font-medium mb-3">Plugin Hosting</div>
                <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500 mb-2">
                  <option>Select Plugin...</option>
                  <option>VST3 - FabFilter Pro-Q 3</option>
                  <option>VST3 - Waves SSL E-Channel</option>
                  <option>LV2 - Calf Equalizer</option>
                  <option>CLAP - Surge XT</option>
                </select>
                <button className="w-full px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-sm">
                  Load Plugin
                </button>
              </div>

              <div className="pt-4 border-t border-gray-800">
                <div className="text-sm font-medium mb-3">Automation</div>
                <div className="space-y-2">
                  <button className="w-full px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm text-left">
                    Volume
                  </button>
                  <button className="w-full px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm text-left">
                    Pan
                  </button>
                  <button className="w-full px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm text-left">
                    Send Level
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}