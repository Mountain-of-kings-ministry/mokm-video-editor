import { Play, Pause, SkipBack, SkipForward, Maximize2, Monitor } from 'lucide-react';

export function EditPage() {
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Monitors */}
      <div className="h-1/2 flex border-b border-gray-800">
        {/* Source Monitor */}
        <div className="flex-1 flex flex-col bg-[#0f0f0f] border-r border-gray-800">
          <div className="h-10 bg-black/30 border-b border-gray-800 flex items-center justify-between px-3">
            <span className="text-sm font-medium">Source Monitor</span>
            <button className="p-1 hover:bg-gray-800 rounded">
              <Maximize2 size={14} />
            </button>
          </div>
          <div className="flex-1 bg-black flex items-center justify-center">
            <div className="text-center space-y-3">
              <Monitor size={64} className="mx-auto text-gray-700" />
              <div className="text-sm text-gray-500">No clip selected</div>
            </div>
          </div>
          <div className="h-16 bg-[#0f0f0f] border-t border-gray-800 flex items-center justify-center gap-2">
            <button className="p-2 hover:bg-gray-800 rounded">
              <SkipBack size={18} />
            </button>
            <button className="p-2 bg-blue-600 hover:bg-blue-700 rounded">
              <Play size={18} />
            </button>
            <button className="p-2 hover:bg-gray-800 rounded">
              <SkipForward size={18} />
            </button>
            <div className="ml-4 text-sm font-mono">00:00:00:00</div>
          </div>
        </div>

        {/* Program Monitor */}
        <div className="flex-1 flex flex-col bg-[#0f0f0f]">
          <div className="h-10 bg-black/30 border-b border-gray-800 flex items-center justify-between px-3">
            <span className="text-sm font-medium">Program Monitor</span>
            <div className="flex items-center gap-2">
              <button className="px-2 py-1 text-xs bg-gray-800 hover:bg-gray-700 rounded">Proxy</button>
              <button className="px-2 py-1 text-xs bg-blue-600 hover:bg-blue-700 rounded">High-Res</button>
              <button className="p-1 hover:bg-gray-800 rounded">
                <Maximize2 size={14} />
              </button>
            </div>
          </div>
          <div className="flex-1 bg-black flex items-center justify-center">
            <div className="aspect-video w-full max-w-4xl bg-gray-900 border-2 border-gray-800 flex items-center justify-center">
              <div className="text-center space-y-3">
                <Monitor size={64} className="mx-auto text-gray-700" />
                <div className="text-sm text-gray-500">Timeline Preview</div>
              </div>
            </div>
          </div>
          <div className="h-16 bg-[#0f0f0f] border-t border-gray-800 flex items-center justify-center gap-2">
            <button className="p-2 hover:bg-gray-800 rounded">
              <SkipBack size={18} />
            </button>
            <button className="p-2 bg-blue-600 hover:bg-blue-700 rounded">
              <Play size={18} />
            </button>
            <button className="p-2 hover:bg-gray-800 rounded">
              <SkipForward size={18} />
            </button>
            <div className="ml-4 text-sm font-mono">00:00:00:00</div>
            <div className="ml-auto mr-4 text-xs text-gray-500">24 fps | 1920x1080</div>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="flex-1 flex flex-col bg-[#1a1a1a]">
        {/* Timeline Toolbar */}
        <div className="h-10 bg-[#0f0f0f] border-b border-gray-800 flex items-center justify-between px-3">
          <div className="flex items-center gap-2">
            <button className="px-2 py-1 text-xs bg-blue-600 rounded">Selection</button>
            <button className="px-2 py-1 text-xs bg-gray-800 hover:bg-gray-700 rounded">Razor</button>
            <button className="px-2 py-1 text-xs bg-gray-800 hover:bg-gray-700 rounded">Slip</button>
            <button className="px-2 py-1 text-xs bg-gray-800 hover:bg-gray-700 rounded">Slide</button>
            <button className="px-2 py-1 text-xs bg-gray-800 hover:bg-gray-700 rounded">Ripple</button>
          </div>
          <div className="flex items-center gap-2">
            <button className="px-2 py-1 text-xs bg-gray-800 hover:bg-gray-700 rounded">Snap</button>
            <input type="range" min="10" max="200" defaultValue="100" className="w-24" />
            <span className="text-xs text-gray-500">100%</span>
          </div>
        </div>

        {/* Timeline Ruler */}
        <div className="h-8 bg-[#0f0f0f] border-b border-gray-800 flex items-center px-4 relative">
          <div className="flex gap-20 text-xs font-mono text-gray-500">
            <span>00:00</span>
            <span>00:10</span>
            <span>00:20</span>
            <span>00:30</span>
            <span>00:40</span>
            <span>00:50</span>
            <span>01:00</span>
          </div>
          <div className="absolute left-40 top-0 bottom-0 w-0.5 bg-red-500"></div>
        </div>

        {/* Timeline Tracks */}
        <div className="flex-1 overflow-auto">
          {/* Video Tracks */}
          <div className="flex">
            <div className="w-32 flex-shrink-0">
              <div className="h-16 bg-[#0f0f0f] border-b border-r border-gray-800 flex items-center px-3 text-sm">
                <span>Video 3</span>
              </div>
            </div>
            <div className="flex-1 h-16 bg-[#1a1a1a] border-b border-gray-800 relative">
              {/* Empty track */}
            </div>
          </div>

          <div className="flex">
            <div className="w-32 flex-shrink-0">
              <div className="h-16 bg-[#0f0f0f] border-b border-r border-gray-800 flex items-center px-3 text-sm">
                <span>Video 2</span>
              </div>
            </div>
            <div className="flex-1 h-16 bg-[#1a1a1a] border-b border-gray-800 relative">
              <div className="absolute left-20 top-2 h-12 w-32 bg-purple-600/80 border border-purple-500 rounded flex items-center justify-center text-xs">
                Logo.mp4
              </div>
            </div>
          </div>

          <div className="flex">
            <div className="w-32 flex-shrink-0">
              <div className="h-16 bg-[#0f0f0f] border-b border-r border-gray-800 flex items-center px-3 text-sm">
                <span>Video 1</span>
              </div>
            </div>
            <div className="flex-1 h-16 bg-[#1a1a1a] border-b border-gray-800 relative">
              <div className="absolute left-10 top-2 h-12 w-64 bg-blue-600/80 border border-blue-500 rounded flex items-center justify-center text-xs">
                Interview_Take_01.mp4
              </div>
              <div className="absolute left-80 top-2 h-12 w-48 bg-green-600/80 border border-green-500 rounded flex items-center justify-center text-xs">
                Broll_Sunset.mp4
              </div>
            </div>
          </div>

          {/* Audio Tracks */}
          <div className="flex">
            <div className="w-32 flex-shrink-0">
              <div className="h-12 bg-[#0f0f0f] border-b border-r border-gray-800 flex items-center px-3 text-sm">
                <span>Audio 2</span>
              </div>
            </div>
            <div className="flex-1 h-12 bg-[#1a1a1a] border-b border-gray-800 relative">
              <div className="absolute left-10 top-1 h-10 w-96 bg-orange-600/50 border border-orange-500 rounded">
                <div className="h-full w-full bg-gradient-to-r from-orange-500/30 to-orange-600/30" style={{
                  backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 2px, rgba(255,255,255,0.1) 2px, rgba(255,255,255,0.1) 4px)'
                }}></div>
              </div>
            </div>
          </div>

          <div className="flex">
            <div className="w-32 flex-shrink-0">
              <div className="h-12 bg-[#0f0f0f] border-b border-r border-gray-800 flex items-center px-3 text-sm">
                <span>Audio 1</span>
              </div>
            </div>
            <div className="flex-1 h-12 bg-[#1a1a1a] border-b border-gray-800 relative">
              <div className="absolute left-10 top-1 h-10 w-64 bg-teal-600/50 border border-teal-500 rounded">
                <div className="h-full w-full bg-gradient-to-r from-teal-500/30 to-teal-600/30" style={{
                  backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 2px, rgba(255,255,255,0.1) 2px, rgba(255,255,255,0.1) 4px)'
                }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}