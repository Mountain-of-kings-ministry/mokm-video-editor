import { Search, RotateCcw } from 'lucide-react';

interface Shortcut {
  id: string;
  action: string;
  category: string;
  keys: string;
  description: string;
}

export function KeyboardMapper() {
  const shortcuts: Shortcut[] = [
    // Playback
    { id: '1', action: 'Play/Pause', category: 'Playback', keys: 'Space', description: 'Toggle playback' },
    { id: '2', action: 'Step Forward', category: 'Playback', keys: 'Right Arrow', description: 'Move forward one frame' },
    { id: '3', action: 'Step Backward', category: 'Playback', keys: 'Left Arrow', description: 'Move backward one frame' },
    { id: '4', action: 'Go to Start', category: 'Playback', keys: 'Home', description: 'Jump to timeline start' },
    { id: '5', action: 'Go to End', category: 'Playback', keys: 'End', description: 'Jump to timeline end' },

    // Editing
    { id: '6', action: 'Cut', category: 'Editing', keys: 'Ctrl+X', description: 'Cut selected clip' },
    { id: '7', action: 'Copy', category: 'Editing', keys: 'Ctrl+C', description: 'Copy selected clip' },
    { id: '8', action: 'Paste', category: 'Editing', keys: 'Ctrl+V', description: 'Paste clip' },
    { id: '9', action: 'Delete', category: 'Editing', keys: 'Delete', description: 'Delete selected clip' },
    { id: '10', action: 'Razor Tool', category: 'Editing', keys: 'C', description: 'Activate razor tool' },
    { id: '11', action: 'Selection Tool', category: 'Editing', keys: 'V', description: 'Activate selection tool' },

    // View
    { id: '12', action: 'Zoom In', category: 'View', keys: 'Ctrl+=', description: 'Zoom in timeline' },
    { id: '13', action: 'Zoom Out', category: 'View', keys: 'Ctrl+-', description: 'Zoom out timeline' },
    { id: '14', action: 'Fit to Window', category: 'View', keys: 'Shift+Z', description: 'Fit timeline to window' },
    { id: '15', action: 'Toggle Fullscreen', category: 'View', keys: 'F11', description: 'Toggle fullscreen mode' },

    // Navigation
    { id: '16', action: 'Media Page', category: 'Navigation', keys: 'Ctrl+1', description: 'Switch to media page' },
    { id: '17', action: 'Edit Page', category: 'Navigation', keys: 'Ctrl+2', description: 'Switch to edit page' },
    { id: '18', action: 'Color Page', category: 'Navigation', keys: 'Ctrl+3', description: 'Switch to color page' },

    // Marks
    { id: '19', action: 'Set In Point', category: 'Marks', keys: 'I', description: 'Set in point' },
    { id: '20', action: 'Set Out Point', category: 'Marks', keys: 'O', description: 'Set out point' },
    { id: '21', action: 'Add Marker', category: 'Marks', keys: 'M', description: 'Add marker at playhead' },
  ];

  const categories = Array.from(new Set(shortcuts.map(s => s.category)));

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Sidebar */}
      <div className="w-56 bg-[#0f0f0f] border-r border-gray-800 overflow-auto">
        <div className="p-3">
          <div className="space-y-1">
            <button className="w-full px-3 py-2 text-left bg-blue-600 rounded text-sm">All Shortcuts</button>
            {categories.map(category => (
              <button key={category} className="w-full px-3 py-2 text-left hover:bg-gray-800 rounded text-sm">
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <div className="h-14 bg-[#0f0f0f] border-b border-gray-800 flex items-center justify-between px-4">
          <h2 className="font-semibold">Keyboard Shortcuts</h2>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm flex items-center gap-2">
              <RotateCcw size={14} />
              Reset to Defaults
            </button>
            <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-sm">
              Export Preset
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="p-4 bg-[#0f0f0f] border-b border-gray-800">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              placeholder="Search shortcuts..."
              className="w-full pl-9 pr-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Shortcuts Table */}
        <div className="flex-1 overflow-auto">
          <table className="w-full">
            <thead className="bg-[#0f0f0f] sticky top-0 border-b border-gray-800">
              <tr className="text-left text-sm">
                <th className="px-4 py-3 font-medium text-gray-400">Action</th>
                <th className="px-4 py-3 font-medium text-gray-400">Category</th>
                <th className="px-4 py-3 font-medium text-gray-400">Shortcut</th>
                <th className="px-4 py-3 font-medium text-gray-400">Description</th>
                <th className="px-4 py-3 font-medium text-gray-400 w-24">Actions</th>
              </tr>
            </thead>
            <tbody>
              {shortcuts.map((shortcut, index) => (
                <tr
                  key={shortcut.id}
                  className={`border-b border-gray-800 hover:bg-[#0f0f0f] ${
                    index % 2 === 0 ? 'bg-[#1a1a1a]' : ''
                  }`}
                >
                  <td className="px-4 py-3 text-sm font-medium">{shortcut.action}</td>
                  <td className="px-4 py-3 text-sm text-gray-400">{shortcut.category}</td>
                  <td className="px-4 py-3">
                    <div className="inline-flex items-center gap-1 px-2 py-1 bg-gray-800 border border-gray-700 rounded text-xs font-mono">
                      {shortcut.keys}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-500">{shortcut.description}</td>
                  <td className="px-4 py-3">
                    <button className="px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded text-xs">
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Info Footer */}
        <div className="h-12 bg-[#0f0f0f] border-t border-gray-800 flex items-center px-4 text-xs text-gray-500">
          Tip: Click on any shortcut to customize it. Press Escape to cancel recording.
        </div>
      </div>
    </div>
  );
}