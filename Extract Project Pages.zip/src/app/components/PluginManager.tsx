import { CheckCircle, AlertCircle, RefreshCw, Search, X } from 'lucide-react';

interface Plugin {
  id: string;
  name: string;
  type: 'OFX' | 'VST3' | 'LV2' | 'CLAP' | 'Frei0r';
  vendor: string;
  version: string;
  status: 'active' | 'disabled' | 'error';
  path: string;
}

export function PluginManager() {
  const plugins: Plugin[] = [
    { id: '1', name: 'Color Correction Pro', type: 'OFX', vendor: 'Boris FX', version: '1.5.2', status: 'active', path: '/usr/lib/ofx/ColorCorrection.ofx' },
    { id: '2', name: 'Sapphire Blur', type: 'OFX', vendor: 'Boris FX', version: '2024.1', status: 'active', path: '/usr/lib/ofx/Sapphire.ofx' },
    { id: '3', name: 'FabFilter Pro-Q 3', type: 'VST3', vendor: 'FabFilter', version: '3.21', status: 'active', path: '/usr/lib/vst3/ProQ3.vst3' },
    { id: '4', name: 'Waves SSL E-Channel', type: 'VST3', vendor: 'Waves', version: '14.0', status: 'active', path: '/usr/lib/vst3/SSLChannel.vst3' },
    { id: '5', name: 'Calf Equalizer', type: 'LV2', vendor: 'Calf Studio Gear', version: '0.90.3', status: 'active', path: '/usr/lib/lv2/calf.lv2' },
    { id: '6', name: 'Surge XT', type: 'CLAP', vendor: 'Surge Synth Team', version: '1.2.0', status: 'active', path: '/usr/lib/clap/SurgeXT.clap' },
    { id: '7', name: 'Cartoon', type: 'Frei0r', vendor: 'Frei0r', version: '1.8', status: 'active', path: '/usr/lib/frei0r-1/cartoon.so' },
    { id: '8', name: 'Glow', type: 'Frei0r', vendor: 'Frei0r', version: '1.8', status: 'disabled', path: '/usr/lib/frei0r-1/glow.so' },
  ];

  const videoPlugins = plugins.filter(p => p.type === 'OFX' || p.type === 'Frei0r');
  const audioPlugins = plugins.filter(p => p.type === 'VST3' || p.type === 'LV2' || p.type === 'CLAP');

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <div className="flex items-center gap-1 text-xs text-green-500">
            <CheckCircle size={14} />
            <span>Active</span>
          </div>
        );
      case 'disabled':
        return <div className="text-xs text-gray-500">Disabled</div>;
      case 'error':
        return (
          <div className="flex items-center gap-1 text-xs text-red-500">
            <AlertCircle size={14} />
            <span>Error</span>
          </div>
        );
      default:
        return null;
    }
  };

  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      OFX: 'bg-purple-600/20 text-purple-400 border-purple-600/30',
      VST3: 'bg-blue-600/20 text-blue-400 border-blue-600/30',
      LV2: 'bg-green-600/20 text-green-400 border-green-600/30',
      CLAP: 'bg-orange-600/20 text-orange-400 border-orange-600/30',
      Frei0r: 'bg-pink-600/20 text-pink-400 border-pink-600/30',
    };
    return (
      <div className={`px-2 py-0.5 text-xs font-medium border rounded ${colors[type]}`}>
        {type}
      </div>
    );
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Main Panel */}
      <div className="flex-1 flex flex-col">
        <div className="h-14 bg-[#0f0f0f] border-b border-gray-800 flex items-center justify-between px-4">
          <h2 className="font-semibold">Plugin Manager</h2>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm flex items-center gap-2">
              <RefreshCw size={14} />
              Rescan Plugins
            </button>
            <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-sm">
              Add Plugin Path
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="p-4 bg-[#0f0f0f] border-b border-gray-800">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              placeholder="Search plugins..."
              className="w-full pl-9 pr-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Plugin Lists */}
        <div className="flex-1 overflow-auto p-4 space-y-6">
          {/* Video Plugins */}
          <div>
            <h3 className="text-sm font-semibold text-gray-400 mb-3">
              VIDEO EFFECTS ({videoPlugins.length})
            </h3>
            <div className="space-y-2">
              {videoPlugins.map(plugin => (
                <div key={plugin.id} className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="font-medium">{plugin.name}</div>
                        {getTypeBadge(plugin.type)}
                        {getStatusBadge(plugin.status)}
                      </div>
                      <div className="text-sm text-gray-500 space-y-1">
                        <div>Vendor: {plugin.vendor} • Version: {plugin.version}</div>
                        <div className="text-xs truncate">Path: {plugin.path}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          defaultChecked={plugin.status === 'active'}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                      <button className="p-1 hover:bg-gray-800 rounded">
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Audio Plugins */}
          <div>
            <h3 className="text-sm font-semibold text-gray-400 mb-3">
              AUDIO EFFECTS ({audioPlugins.length})
            </h3>
            <div className="space-y-2">
              {audioPlugins.map(plugin => (
                <div key={plugin.id} className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="font-medium">{plugin.name}</div>
                        {getTypeBadge(plugin.type)}
                        {getStatusBadge(plugin.status)}
                      </div>
                      <div className="text-sm text-gray-500 space-y-1">
                        <div>Vendor: {plugin.vendor} • Version: {plugin.version}</div>
                        <div className="text-xs truncate">Path: {plugin.path}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          defaultChecked={plugin.status === 'active'}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                      <button className="p-1 hover:bg-gray-800 rounded">
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Settings Panel */}
      <div className="w-96 bg-[#0f0f0f] border-l border-gray-800 overflow-auto">
        <div className="p-4">
          <h3 className="font-semibold mb-4">Plugin Paths</h3>

          <div className="space-y-4">
            {/* OFX Paths */}
            <div>
              <div className="text-sm font-medium mb-2">OpenFX (OFX)</div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    defaultValue="/usr/lib/ofx"
                    className="flex-1 px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                    readOnly
                  />
                  <button className="p-1.5 hover:bg-gray-800 rounded">
                    <X size={14} />
                  </button>
                </div>
                <button className="w-full px-3 py-1.5 border border-dashed border-gray-700 rounded text-sm text-gray-500 hover:text-white hover:border-gray-600">
                  + Add Path
                </button>
              </div>
            </div>

            {/* VST3 Paths */}
            <div className="pt-4 border-t border-gray-800">
              <div className="text-sm font-medium mb-2">VST3</div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    defaultValue="/usr/lib/vst3"
                    className="flex-1 px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                    readOnly
                  />
                  <button className="p-1.5 hover:bg-gray-800 rounded">
                    <X size={14} />
                  </button>
                </div>
                <button className="w-full px-3 py-1.5 border border-dashed border-gray-700 rounded text-sm text-gray-500 hover:text-white hover:border-gray-600">
                  + Add Path
                </button>
              </div>
            </div>

            {/* LV2 Paths */}
            <div className="pt-4 border-t border-gray-800">
              <div className="text-sm font-medium mb-2">LV2</div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    defaultValue="/usr/lib/lv2"
                    className="flex-1 px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                    readOnly
                  />
                  <button className="p-1.5 hover:bg-gray-800 rounded">
                    <X size={14} />
                  </button>
                </div>
                <button className="w-full px-3 py-1.5 border border-dashed border-gray-700 rounded text-sm text-gray-500 hover:text-white hover:border-gray-600">
                  + Add Path
                </button>
              </div>
            </div>

            {/* CLAP Paths */}
            <div className="pt-4 border-t border-gray-800">
              <div className="text-sm font-medium mb-2">CLAP</div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    defaultValue="/usr/lib/clap"
                    className="flex-1 px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                    readOnly
                  />
                  <button className="p-1.5 hover:bg-gray-800 rounded">
                    <X size={14} />
                  </button>
                </div>
                <button className="w-full px-3 py-1.5 border border-dashed border-gray-700 rounded text-sm text-gray-500 hover:text-white hover:border-gray-600">
                  + Add Path
                </button>
              </div>
            </div>

            {/* Frei0r Paths */}
            <div className="pt-4 border-t border-gray-800">
              <div className="text-sm font-medium mb-2">Frei0r</div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    defaultValue="/usr/lib/frei0r-1"
                    className="flex-1 px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                    readOnly
                  />
                  <button className="p-1.5 hover:bg-gray-800 rounded">
                    <X size={14} />
                  </button>
                </div>
                <button className="w-full px-3 py-1.5 border border-dashed border-gray-700 rounded text-sm text-gray-500 hover:text-white hover:border-gray-600">
                  + Add Path
                </button>
              </div>
            </div>

            {/* Scan Settings */}
            <div className="pt-4 border-t border-gray-800">
              <div className="text-sm font-medium mb-3">Scan Settings</div>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-sm">Auto-scan on startup</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-sm">Enable plugin sandboxing</span>
                </label>
              </div>
            </div>

            {/* Statistics */}
            <div className="pt-4 border-t border-gray-800">
              <div className="text-sm font-medium mb-3">Statistics</div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Total Plugins:</span>
                  <span>{plugins.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Active:</span>
                  <span className="text-green-500">{plugins.filter(p => p.status === 'active').length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Disabled:</span>
                  <span className="text-gray-500">{plugins.filter(p => p.status === 'disabled').length}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}