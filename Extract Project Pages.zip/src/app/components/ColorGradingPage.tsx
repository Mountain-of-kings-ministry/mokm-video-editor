import { Monitor } from 'lucide-react';

export function ColorGradingPage() {
  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Main Viewer */}
      <div className="flex-1 flex flex-col bg-[#0f0f0f]">
        <div className="h-10 bg-black/30 border-b border-gray-800 flex items-center justify-between px-3">
          <span className="text-sm font-medium">Grading Viewer</span>
          <div className="flex items-center gap-2 text-xs">
            <button className="px-2 py-1 bg-gray-800 hover:bg-gray-700 rounded">Before</button>
            <button className="px-2 py-1 bg-blue-600 hover:bg-blue-700 rounded">After</button>
            <button className="px-2 py-1 bg-gray-800 hover:bg-gray-700 rounded">Split</button>
          </div>
        </div>
        <div className="flex-1 bg-black flex items-center justify-center p-8">
          <div className="aspect-video w-full max-w-5xl bg-gray-900 border border-gray-800 flex items-center justify-center">
            <Monitor size={64} className="text-gray-700" />
          </div>
        </div>
      </div>

      {/* Scopes Panel */}
      <div className="w-96 bg-[#0f0f0f] border-l border-gray-800 flex flex-col">
        <div className="p-3 border-b border-gray-800">
          <h3 className="font-semibold">Video Scopes</h3>
        </div>
        <div className="flex-1 overflow-auto p-3 space-y-3">
          {/* Waveform */}
          <div>
            <div className="text-xs text-gray-500 mb-2">Waveform</div>
            <div className="h-32 bg-black border border-gray-800 rounded relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-b from-green-500/20 via-yellow-500/20 to-red-500/20" />
              <svg className="w-full h-full">
                <path
                  d="M 0 100 Q 50 80, 100 90 T 200 85 T 300 95 T 400 80"
                  stroke="#4ade80"
                  strokeWidth="1"
                  fill="none"
                  opacity="0.7"
                />
              </svg>
            </div>
          </div>

          {/* Parade RGB */}
          <div>
            <div className="text-xs text-gray-500 mb-2">Parade (RGB)</div>
            <div className="h-32 bg-black border border-gray-800 rounded grid grid-cols-3 gap-px overflow-hidden">
              <div className="bg-red-500/10 relative">
                <div className="absolute bottom-0 left-0 right-0 h-3/4 bg-gradient-to-t from-red-500/50 to-transparent" />
              </div>
              <div className="bg-green-500/10 relative">
                <div className="absolute bottom-0 left-0 right-0 h-4/5 bg-gradient-to-t from-green-500/50 to-transparent" />
              </div>
              <div className="bg-blue-500/10 relative">
                <div className="absolute bottom-0 left-0 right-0 h-2/3 bg-gradient-to-t from-blue-500/50 to-transparent" />
              </div>
            </div>
          </div>

          {/* Vectorscope */}
          <div>
            <div className="text-xs text-gray-500 mb-2">Vectorscope</div>
            <div className="aspect-square bg-black border border-gray-800 rounded relative overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full h-full relative">
                  <div className="absolute top-1/2 left-1/2 w-px h-full bg-gray-700 -translate-x-1/2" />
                  <div className="absolute top-1/2 left-1/2 w-full h-px bg-gray-700 -translate-y-1/2" />
                  <div className="absolute top-1/2 left-1/2 w-32 h-32 border border-gray-700 rounded-full -translate-x-1/2 -translate-y-1/2" />
                  <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-yellow-500 rounded-full -translate-x-1/2 -translate-y-1/2 blur-sm" />
                </div>
              </div>
            </div>
          </div>

          {/* Histogram */}
          <div>
            <div className="text-xs text-gray-500 mb-2">Histogram</div>
            <div className="h-24 bg-black border border-gray-800 rounded relative overflow-hidden">
              <svg className="w-full h-full" preserveAspectRatio="none">
                <path
                  d="M 0 96 L 10 90 L 20 75 L 30 60 L 40 45 L 50 30 L 60 20 L 70 15 L 80 12 L 90 15 L 100 20 L 110 30 L 120 45 L 130 60 L 140 75 L 150 85 L 160 90 L 170 92 L 180 93 L 190 94 L 200 95 L 210 96"
                  fill="rgba(255,255,255,0.3)"
                  stroke="white"
                  strokeWidth="1"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Color Wheels Panel */}
      <div className="w-[480px] bg-[#0f0f0f] border-l border-gray-800 overflow-auto">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Primary Grading</h3>
            <button className="text-xs text-blue-500 hover:underline">Reset All</button>
          </div>

          {/* Color Space Selector */}
          <div className="mb-6">
            <label className="text-xs text-gray-500 block mb-2">Color Space</label>
            <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
              <option>Rec.709</option>
              <option>ACES</option>
              <option>DCI-P3</option>
              <option>Rec.2020</option>
            </select>
          </div>

          {/* Color Wheels */}
          <div className="space-y-6">
            {['Lift', 'Gamma', 'Gain'].map(wheel => (
              <div key={wheel}>
                <div className="text-sm font-medium mb-3">{wheel}</div>
                <div className="flex gap-4">
                  <div className="flex-1">
                    <div className="aspect-square bg-gradient-to-br from-red-500 via-green-500 to-blue-500 rounded-full border-4 border-gray-700 relative">
                      <div className="absolute top-1/2 left-1/2 w-4 h-4 bg-white border-2 border-gray-900 rounded-full -translate-x-1/2 -translate-y-1/2 cursor-move" />
                    </div>
                  </div>
                  <div className="w-16 space-y-2">
                    <div>
                      <label className="text-xs text-gray-500">Master</label>
                      <input
                        type="range"
                        min="-100"
                        max="100"
                        defaultValue="0"
                        className="w-full"
                        orient="vertical"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Offset */}
          <div className="mt-6 pt-6 border-t border-gray-800">
            <div className="text-sm font-medium mb-3">Offset</div>
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-gray-500">Temperature</label>
                  <span className="text-xs font-mono">0</span>
                </div>
                <input type="range" min="-100" max="100" defaultValue="0" className="w-full" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-gray-500">Tint</label>
                  <span className="text-xs font-mono">0</span>
                </div>
                <input type="range" min="-100" max="100" defaultValue="0" className="w-full" />
              </div>
            </div>
          </div>

          {/* Additional Controls */}
          <div className="mt-6 pt-6 border-t border-gray-800 space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs text-gray-500">Contrast</label>
                <span className="text-xs font-mono">1.0</span>
              </div>
              <input type="range" min="0" max="2" step="0.01" defaultValue="1" className="w-full" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs text-gray-500">Saturation</label>
                <span className="text-xs font-mono">1.0</span>
              </div>
              <input type="range" min="0" max="2" step="0.01" defaultValue="1" className="w-full" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs text-gray-500">Exposure</label>
                <span className="text-xs font-mono">0.0</span>
              </div>
              <input type="range" min="-3" max="3" step="0.1" defaultValue="0" className="w-full" />
            </div>
          </div>

          {/* LUT Selector */}
          <div className="mt-6 pt-6 border-t border-gray-800">
            <label className="text-xs text-gray-500 block mb-2">LUT</label>
            <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
              <option>None</option>
              <option>Cinematic_01.cube</option>
              <option>Warm_Film.cube</option>
              <option>Cool_Modern.cube</option>
              <option>Vintage_Fade.cube</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}