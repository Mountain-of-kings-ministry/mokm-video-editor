import { Play, CheckCircle, Clock, AlertCircle, Plus, X } from 'lucide-react';

interface RenderJob {
  id: string;
  name: string;
  status: 'pending' | 'rendering' | 'complete' | 'failed';
  progress?: number;
  preset: string;
  output: string;
  estimatedTime?: string;
}

export function ExportPage() {
  const renderQueue: RenderJob[] = [
    { id: '1', name: 'Project_Final_v3.mp4', status: 'complete', progress: 100, preset: 'YouTube 1080p', output: '/exports/Project_Final_v3.mp4' },
    { id: '2', name: 'Project_Instagram_Square.mp4', status: 'rendering', progress: 67, preset: 'Instagram Square', output: '/exports/Project_Instagram_Square.mp4', estimatedTime: '2m 15s' },
    { id: '3', name: 'Project_ProRes_Master.mov', status: 'pending', preset: 'ProRes 422 HQ', output: '/exports/Project_ProRes_Master.mov', estimatedTime: '8m 30s' },
  ];

  const exportPresets = [
    { name: 'YouTube 1080p', codec: 'H.264', resolution: '1920x1080', fps: 30, bitrate: '8 Mbps' },
    { name: 'YouTube 4K', codec: 'H.264', resolution: '3840x2160', fps: 30, bitrate: '45 Mbps' },
    { name: 'Instagram Square', codec: 'H.264', resolution: '1080x1080', fps: 30, bitrate: '5 Mbps' },
    { name: 'Instagram Story', codec: 'H.264', resolution: '1080x1920', fps: 30, bitrate: '5 Mbps' },
    { name: 'ProRes 422', codec: 'ProRes 422', resolution: 'Source', fps: 'Source', bitrate: 'VBR' },
    { name: 'ProRes 422 HQ', codec: 'ProRes 422 HQ', resolution: 'Source', fps: 'Source', bitrate: 'VBR' },
    { name: 'DNxHD', codec: 'DNxHD', resolution: '1920x1080', fps: 24, bitrate: '145 Mbps' },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'complete': return <CheckCircle size={18} className="text-green-500" />;
      case 'rendering': return <Play size={18} className="text-blue-500" />;
      case 'pending': return <Clock size={18} className="text-gray-500" />;
      case 'failed': return <AlertCircle size={18} className="text-red-500" />;
      default: return null;
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Render Queue */}
      <div className="flex-1 flex flex-col">
        <div className="h-14 bg-[#0f0f0f] border-b border-gray-800 flex items-center justify-between px-4">
          <h2 className="font-semibold">Render Queue</h2>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm">Clear Completed</button>
            <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-sm flex items-center gap-2">
              <Plus size={14} />
              Add to Queue
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4">
          <div className="space-y-3">
            {renderQueue.map(job => (
              <div key={job.id} className="bg-[#0f0f0f] border border-gray-800 rounded-lg overflow-hidden">
                <div className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="mt-1">{getStatusIcon(job.status)}</div>
                      <div className="flex-1">
                        <div className="font-medium mb-1">{job.name}</div>
                        <div className="text-sm text-gray-500 space-y-1">
                          <div>Preset: {job.preset}</div>
                          <div className="truncate">Output: {job.output}</div>
                        </div>
                      </div>
                    </div>
                    <button className="p-1 hover:bg-gray-800 rounded">
                      <X size={16} />
                    </button>
                  </div>

                  {job.status === 'rendering' && job.progress !== undefined && (
                    <div>
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="text-gray-500">Rendering...</span>
                        <span className="font-mono">{job.progress}%</span>
                      </div>
                      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 transition-all"
                          style={{ width: `${job.progress}%` }}
                        />
                      </div>
                      {job.estimatedTime && (
                        <div className="text-xs text-gray-500 mt-2">Est. time remaining: {job.estimatedTime}</div>
                      )}
                    </div>
                  )}

                  {job.status === 'pending' && (
                    <div className="text-xs text-gray-500">
                      Waiting in queue • Est. time: {job.estimatedTime}
                    </div>
                  )}

                  {job.status === 'complete' && (
                    <div className="flex items-center gap-2">
                      <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm">
                        Show in Folder
                      </button>
                      <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm">
                        Play
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {renderQueue.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-500 mb-4">No items in render queue</div>
                <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded">
                  Add Export Job
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Export Settings */}
      <div className="w-96 bg-[#0f0f0f] border-l border-gray-800 overflow-auto">
        <div className="p-4">
          <h3 className="font-semibold mb-4">Export Settings</h3>

          <div className="space-y-4">
            {/* Preset Selector */}
            <div>
              <label className="text-xs text-gray-500 block mb-2">Preset</label>
              <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
                <option>Custom</option>
                {exportPresets.map(preset => (
                  <option key={preset.name}>{preset.name}</option>
                ))}
              </select>
            </div>

            {/* Output File */}
            <div>
              <label className="text-xs text-gray-500 block mb-2">Output File</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  defaultValue="/exports/output.mp4"
                  className="flex-1 px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                />
                <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm">
                  Browse
                </button>
              </div>
            </div>

            {/* Format */}
            <div>
              <label className="text-xs text-gray-500 block mb-2">Format</label>
              <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
                <option>MP4</option>
                <option>MOV</option>
                <option>MKV</option>
                <option>AVI</option>
                <option>WebM</option>
              </select>
            </div>

            {/* Video Codec */}
            <div>
              <label className="text-xs text-gray-500 block mb-2">Video Codec</label>
              <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
                <option>H.264 (AVC)</option>
                <option>H.265 (HEVC)</option>
                <option>ProRes 422</option>
                <option>ProRes 422 HQ</option>
                <option>DNxHD</option>
                <option>VP9</option>
              </select>
            </div>

            {/* Resolution */}
            <div>
              <label className="text-xs text-gray-500 block mb-2">Resolution</label>
              <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
                <option>Source (1920x1080)</option>
                <option>3840x2160 (4K)</option>
                <option>1920x1080 (1080p)</option>
                <option>1280x720 (720p)</option>
                <option>1080x1080 (Square)</option>
                <option>1080x1920 (Vertical)</option>
              </select>
            </div>

            {/* Frame Rate */}
            <div>
              <label className="text-xs text-gray-500 block mb-2">Frame Rate</label>
              <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
                <option>Source (24 fps)</option>
                <option>23.976 fps</option>
                <option>24 fps</option>
                <option>25 fps</option>
                <option>29.97 fps</option>
                <option>30 fps</option>
                <option>60 fps</option>
              </select>
            </div>

            {/* Bitrate */}
            <div>
              <label className="text-xs text-gray-500 block mb-2">Bitrate</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  defaultValue="8"
                  className="flex-1 px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                />
                <select className="px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
                  <option>Mbps</option>
                  <option>Kbps</option>
                </select>
              </div>
            </div>

            {/* Audio Settings */}
            <div className="pt-4 border-t border-gray-800">
              <div className="text-sm font-medium mb-3">Audio</div>
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-gray-500 block mb-2">Audio Codec</label>
                  <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
                    <option>AAC</option>
                    <option>MP3</option>
                    <option>PCM</option>
                    <option>Opus</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 block mb-2">Sample Rate</label>
                  <select className="w-full px-3 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500">
                    <option>48 kHz</option>
                    <option>44.1 kHz</option>
                    <option>96 kHz</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Hardware Acceleration */}
            <div className="pt-4 border-t border-gray-800">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded" />
                <span className="text-sm">Hardware Acceleration (NVENC)</span>
              </label>
            </div>

            {/* Use Original Sources */}
            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded" />
                <span className="text-sm">Use Original Sources (not proxies)</span>
              </label>
            </div>

            {/* Export Button */}
            <div className="pt-4">
              <button className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded font-medium">
                Add to Render Queue
              </button>
            </div>

            {/* Estimated File Size */}
            <div className="text-xs text-gray-500 text-center">
              Estimated file size: 245 MB
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}