export function Preferences() {
  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Sidebar */}
      <div className="w-56 bg-[#0f0f0f] border-r border-gray-800 overflow-auto">
        <div className="p-3">
          <div className="space-y-1">
            <button className="w-full px-3 py-2 text-left bg-blue-600 rounded text-sm">General</button>
            <button className="w-full px-3 py-2 text-left hover:bg-gray-800 rounded text-sm">Performance</button>
            <button className="w-full px-3 py-2 text-left hover:bg-gray-800 rounded text-sm">Playback</button>
            <button className="w-full px-3 py-2 text-left hover:bg-gray-800 rounded text-sm">Memory</button>
            <button className="w-full px-3 py-2 text-left hover:bg-gray-800 rounded text-sm">GPU</button>
            <button className="w-full px-3 py-2 text-left hover:bg-gray-800 rounded text-sm">Appearance</button>
            <button className="w-full px-3 py-2 text-left hover:bg-gray-800 rounded text-sm">Keyboard</button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-3xl p-8">
          <h1 className="text-2xl font-bold mb-6">Preferences</h1>

          <div className="space-y-6">
            {/* General */}
            <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
              <h2 className="text-lg font-semibold mb-4">General</h2>
              <div className="space-y-4">
                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded" />
                    <span className="text-sm">Auto-save project every 5 minutes</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded" />
                    <span className="text-sm">Load last project on startup</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" className="rounded" />
                    <span className="text-sm">Show splash screen on startup</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-gray-800">
                  <label className="text-sm text-gray-400 block mb-2">Default Media Location</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      defaultValue="/home/user/Videos"
                      className="flex-1 px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                    />
                    <button className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded text-sm">Browse</button>
                  </div>
                </div>
              </div>
            </div>

            {/* Performance */}
            <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
              <h2 className="text-lg font-semibold mb-4">Performance</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Hardware Decoding</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option>Disabled</option>
                    <option selected>Auto-detect</option>
                    <option>NVENC (NVIDIA)</option>
                    <option>QuickSync (Intel)</option>
                    <option>VAAPI (Linux)</option>
                    <option>VideoToolbox (macOS)</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-2">Hardware Encoding</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option>Disabled</option>
                    <option selected>Auto-detect</option>
                    <option>NVENC (NVIDIA)</option>
                    <option>QuickSync (Intel)</option>
                    <option>VAAPI (Linux)</option>
                  </select>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded" />
                    <span className="text-sm">Enable SIMD optimizations (SSE/AVX)</span>
                  </label>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded" />
                    <span className="text-sm">Zero-copy rendering pipeline</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Memory */}
            <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
              <h2 className="text-lg font-semibold mb-4">Memory & Cache</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">RAM Reserved for Application</label>
                  <div className="flex items-center gap-4">
                    <input
                      type="range"
                      min="512"
                      max="32768"
                      defaultValue="8192"
                      className="flex-1"
                    />
                    <span className="text-sm font-mono w-20 text-right">8 GB</span>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">Total available: 16 GB</div>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-2">Cache Size</label>
                  <div className="flex items-center gap-4">
                    <input
                      type="range"
                      min="1"
                      max="100"
                      defaultValue="25"
                      className="flex-1"
                    />
                    <span className="text-sm font-mono w-20 text-right">25 GB</span>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-2">Cache Location</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      defaultValue="/tmp/video-editor-cache"
                      className="flex-1 px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                    />
                    <button className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded text-sm">Browse</button>
                  </div>
                </div>

                <button className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded text-sm">
                  Clear Cache Now
                </button>
              </div>
            </div>

            {/* GPU */}
            <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
              <h2 className="text-lg font-semibold mb-4">GPU Acceleration</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Graphics API</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option selected>Auto-detect</option>
                    <option>Vulkan</option>
                    <option>Metal (macOS)</option>
                    <option>Direct3D 11 (Windows)</option>
                    <option>OpenGL</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-2">GPU Device</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option selected>NVIDIA GeForce RTX 3060 (6 GB)</option>
                    <option>Integrated Graphics</option>
                  </select>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded" />
                    <span className="text-sm">Use GPU for effects processing</span>
                  </label>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded" />
                    <span className="text-sm">Use GPU for color grading</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Appearance */}
            <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
              <h2 className="text-lg font-semibold mb-4">Appearance</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Theme</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option selected>Dark (Default)</option>
                    <option>Light</option>
                    <option>High Contrast</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-2">UI Scale</label>
                  <div className="flex items-center gap-4">
                    <input
                      type="range"
                      min="80"
                      max="150"
                      defaultValue="100"
                      className="flex-1"
                    />
                    <span className="text-sm font-mono w-16 text-right">100%</span>
                  </div>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded" />
                    <span className="text-sm">Show tooltips</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Save Buttons */}
            <div className="flex justify-end gap-3">
              <button className="px-6 py-2 bg-gray-800 hover:bg-gray-700 rounded">Reset to Defaults</button>
              <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded font-medium">Save Preferences</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}