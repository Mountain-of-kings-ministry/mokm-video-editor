import { CheckCircle, Clock, AlertCircle, Play, Pause, X } from 'lucide-react';

interface ProxyJob {
  id: string;
  filename: string;
  status: 'queued' | 'transcoding' | 'complete' | 'failed';
  progress?: number;
  originalSize: string;
  proxySize?: string;
  codec: string;
}

export function ProxyManager() {
  const proxyJobs: ProxyJob[] = [
    { id: '1', filename: 'Interview_Take_01.mp4', status: 'complete', progress: 100, originalSize: '842 MB', proxySize: '126 MB', codec: 'ProRes Proxy' },
    { id: '2', filename: 'Broll_Sunset.mp4', status: 'transcoding', progress: 45, originalSize: '1.2 GB', codec: 'ProRes Proxy' },
    { id: '3', filename: 'Logo_Animation.mp4', status: 'queued', originalSize: '45 MB', codec: 'ProRes Proxy' },
    { id: '4', filename: 'Interview_Take_02.mp4', status: 'complete', progress: 100, originalSize: '795 MB', proxySize: '119 MB', codec: 'ProRes Proxy' },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'complete': return <CheckCircle size={18} className="text-green-500" />;
      case 'transcoding': return <Play size={18} className="text-blue-500" />;
      case 'queued': return <Clock size={18} className="text-gray-500" />;
      case 'failed': return <AlertCircle size={18} className="text-red-500" />;
      default: return null;
    }
  };

  const totalOriginal = 2.86;
  const totalProxy = 0.37;
  const spaceSaved = ((totalOriginal - totalProxy) / totalOriginal * 100).toFixed(1);

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Main Panel */}
      <div className="flex-1 flex flex-col">
        <div className="h-14 bg-[#0f0f0f] border-b border-gray-800 flex items-center justify-between px-4">
          <h2 className="font-semibold">Proxy Manager</h2>
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-800 rounded" title="Pause Queue">
              <Pause size={18} />
            </button>
            <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-sm">
              Generate All Proxies
            </button>
          </div>
        </div>

        {/* Statistics */}
        <div className="bg-[#0f0f0f] border-b border-gray-800 p-4">
          <div className="grid grid-cols-4 gap-4">
            <div className="bg-[#1a1a1a] rounded-lg p-4">
              <div className="text-xs text-gray-500 mb-1">Total Files</div>
              <div className="text-2xl font-bold">4</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-lg p-4">
              <div className="text-xs text-gray-500 mb-1">Proxies Created</div>
              <div className="text-2xl font-bold text-green-500">2</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-lg p-4">
              <div className="text-xs text-gray-500 mb-1">Space Saved</div>
              <div className="text-2xl font-bold text-blue-500">{spaceSaved}%</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-lg p-4">
              <div className="text-xs text-gray-500 mb-1">Queue Status</div>
              <div className="text-2xl font-bold text-yellow-500">Active</div>
            </div>
          </div>
        </div>

        {/* Proxy Queue */}
        <div className="flex-1 overflow-auto p-4">
          <div className="space-y-3">
            {proxyJobs.map(job => (
              <div key={job.id} className="bg-[#0f0f0f] border border-gray-800 rounded-lg overflow-hidden">
                <div className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="mt-1">{getStatusIcon(job.status)}</div>
                      <div className="flex-1">
                        <div className="font-medium mb-1">{job.filename}</div>
                        <div className="text-sm text-gray-500 space-y-1">
                          <div>Original: {job.originalSize} • Codec: {job.codec}</div>
                          {job.proxySize && <div>Proxy: {job.proxySize}</div>}
                        </div>
                      </div>
                    </div>
                    <button className="p-1 hover:bg-gray-800 rounded">
                      <X size={16} />
                    </button>
                  </div>

                  {job.status === 'transcoding' && job.progress !== undefined && (
                    <div>
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="text-gray-500">Transcoding...</span>
                        <span className="font-mono">{job.progress}%</span>
                      </div>
                      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 transition-all"
                          style={{ width: `${job.progress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {job.status === 'complete' && (
                    <div className="flex items-center gap-2">
                      <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm">
                        Regenerate
                      </button>
                      <button className="px-3 py-1.5 bg-red-600/20 hover:bg-red-600/30 text-red-500 rounded text-sm">
                        Delete Proxy
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Settings Panel */}
      <div className="w-96 bg-[#0f0f0f] border-l border-gray-800 overflow-auto">
        <div className="p-4">
          <h3 className="font-semibold mb-4">Proxy Settings</h3>

          <div className="space-y-4">
            {/* Auto-generate */}
            <div className="bg-[#1a1a1a] border border-gray-700 rounded-lg p-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded" />
                <span className="text-sm font-medium">Auto-generate proxies on import</span>
              </label>
              <div className="text-xs text-gray-500 mt-2">
                Automatically create proxies for all imported media files
              </div>
            </div>

            {/* Codec Selection */}
            <div>
              <label className="text-sm text-gray-400 block mb-2">Proxy Codec</label>
              <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                <option selected>ProRes Proxy</option>
                <option>ProRes LT</option>
                <option>H.264 (Intra-frame)</option>
                <option>DNxHR LB</option>
                <option>MJPEG</option>
              </select>
            </div>

            {/* Resolution */}
            <div>
              <label className="text-sm text-gray-400 block mb-2">Proxy Resolution</label>
              <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                <option>Full (100%)</option>
                <option selected>Half (50%)</option>
                <option>Quarter (25%)</option>
                <option>Custom</option>
              </select>
            </div>

            {/* Storage */}
            <div>
              <label className="text-sm text-gray-400 block mb-2">Proxy Storage Location</label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  defaultValue="/home/user/proxies"
                  className="flex-1 px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
                />
                <button className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded text-sm">
                  Browse
                </button>
              </div>
              <div className="text-xs text-gray-500">
                Current usage: 370 MB / 100 GB
              </div>
            </div>

            {/* Priority */}
            <div>
              <label className="text-sm text-gray-400 block mb-2">Transcoding Priority</label>
              <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                <option>Low (background)</option>
                <option selected>Normal</option>
                <option>High</option>
              </select>
            </div>

            {/* Hardware Acceleration */}
            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded" />
                <span className="text-sm">Use hardware acceleration</span>
              </label>
            </div>

            {/* Delete on Export */}
            <div className="pt-4 border-t border-gray-800">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="rounded" />
                <span className="text-sm">Delete proxies after final export</span>
              </label>
            </div>

            {/* Cleanup */}
            <div className="pt-4 border-t border-gray-800">
              <div className="text-sm font-medium mb-3">Storage Cleanup</div>
              <button className="w-full px-4 py-2 bg-red-600 hover:bg-red-700 rounded text-sm">
                Delete All Proxies
              </button>
              <div className="text-xs text-gray-500 mt-2 text-center">
                This will free up 370 MB
              </div>
            </div>

            {/* Apply Settings */}
            <div className="pt-4">
              <button className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded font-medium">
                Save Settings
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}