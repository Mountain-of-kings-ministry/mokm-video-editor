import { useState } from 'react';
import { Grid, List, Search, FolderPlus, Upload, MoreVertical, Play, CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface MediaItem {
  id: string;
  name: string;
  type: 'video' | 'audio' | 'image';
  duration?: string;
  resolution?: string;
  fps?: number;
  proxyStatus: 'original' | 'pending' | 'active';
  thumbnail?: string;
}

export function MediaPage() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedItem, setSelectedItem] = useState<string | null>(null);

  const mediaItems: MediaItem[] = [
    { id: '1', name: 'Interview_Take_01.mp4', type: 'video', duration: '05:23', resolution: '1920x1080', fps: 24, proxyStatus: 'active' },
    { id: '2', name: 'Broll_Sunset.mp4', type: 'video', duration: '02:15', resolution: '3840x2160', fps: 30, proxyStatus: 'active' },
    { id: '3', name: 'Music_Track.wav', type: 'audio', duration: '03:45', proxyStatus: 'original' },
    { id: '4', name: 'Logo_Animation.mp4', type: 'video', duration: '00:08', resolution: '1920x1080', fps: 60, proxyStatus: 'pending' },
    { id: '5', name: 'Background_01.jpg', type: 'image', resolution: '4096x2304', proxyStatus: 'original' },
    { id: '6', name: 'Interview_Take_02.mp4', type: 'video', duration: '04:52', resolution: '1920x1080', fps: 24, proxyStatus: 'active' },
  ];

  const getProxyIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle size={14} className="text-green-500" />;
      case 'pending': return <Clock size={14} className="text-yellow-500" />;
      default: return <AlertCircle size={14} className="text-gray-500" />;
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Main Media Library */}
      <div className="flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="h-14 bg-[#0f0f0f] border-b border-gray-800 flex items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <h2 className="font-semibold">Media Library</h2>
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input
                type="text"
                placeholder="Search media..."
                className="pl-9 pr-4 py-1.5 bg-[#1a1a1a] border border-gray-700 rounded text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-sm flex items-center gap-2">
              <Upload size={16} />
              Import
            </button>
            <button className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 rounded text-sm flex items-center gap-2">
              <FolderPlus size={16} />
              New Bin
            </button>
            <div className="ml-2 flex border border-gray-700 rounded overflow-hidden">
              <button
                onClick={() => setViewMode('grid')}
                className={`px-2 py-1.5 ${viewMode === 'grid' ? 'bg-gray-700' : 'bg-transparent hover:bg-gray-800'}`}
              >
                <Grid size={16} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-2 py-1.5 ${viewMode === 'list' ? 'bg-gray-700' : 'bg-transparent hover:bg-gray-800'}`}
              >
                <List size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Media Grid/List */}
        <div className="flex-1 overflow-auto p-4">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {mediaItems.map(item => (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item.id)}
                  className={`bg-[#0f0f0f] border rounded-lg overflow-hidden cursor-pointer transition-all ${
                    selectedItem === item.id ? 'border-blue-500 ring-2 ring-blue-500' : 'border-gray-800 hover:border-gray-700'
                  }`}
                >
                  <div className="aspect-video bg-gray-900 flex items-center justify-center relative group">
                    <Play size={32} className="text-gray-600 group-hover:text-white transition-colors" />
                    <div className="absolute top-2 right-2">
                      {getProxyIcon(item.proxyStatus)}
                    </div>
                  </div>
                  <div className="p-3">
                    <div className="text-sm font-medium truncate mb-1">{item.name}</div>
                    <div className="text-xs text-gray-500 space-y-0.5">
                      {item.duration && <div>{item.duration}</div>}
                      {item.resolution && <div>{item.resolution}</div>}
                      {item.fps && <div>{item.fps} fps</div>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-1">
              {mediaItems.map(item => (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item.id)}
                  className={`flex items-center gap-4 px-4 py-3 rounded cursor-pointer transition-colors ${
                    selectedItem === item.id ? 'bg-blue-600' : 'bg-[#0f0f0f] hover:bg-gray-800'
                  }`}
                >
                  <div className="w-10 h-10 bg-gray-900 rounded flex items-center justify-center flex-shrink-0">
                    <Play size={16} className="text-gray-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{item.name}</div>
                  </div>
                  <div className="flex items-center gap-6 text-xs text-gray-400">
                    {item.duration && <span className="w-16">{item.duration}</span>}
                    {item.resolution && <span className="w-24">{item.resolution}</span>}
                    {item.fps && <span className="w-16">{item.fps} fps</span>}
                    <div className="w-20 flex items-center gap-2">
                      {getProxyIcon(item.proxyStatus)}
                      <span className="capitalize text-xs">{item.proxyStatus}</span>
                    </div>
                  </div>
                  <button className="p-1 hover:bg-gray-700 rounded">
                    <MoreVertical size={16} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Metadata Inspector */}
      <div className="w-80 bg-[#0f0f0f] border-l border-gray-800 overflow-auto">
        <div className="p-4 border-b border-gray-800">
          <h3 className="font-semibold mb-4">Metadata Inspector</h3>
          {selectedItem ? (
            <div className="space-y-4">
              <div className="aspect-video bg-gray-900 rounded flex items-center justify-center">
                <Play size={48} className="text-gray-600" />
              </div>
              <div className="space-y-3 text-sm">
                <div>
                  <div className="text-gray-500 text-xs mb-1">File Name</div>
                  <div className="font-medium">Interview_Take_01.mp4</div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-gray-500 text-xs mb-1">Duration</div>
                    <div>05:23</div>
                  </div>
                  <div>
                    <div className="text-gray-500 text-xs mb-1">Frame Rate</div>
                    <div>24 fps</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-gray-500 text-xs mb-1">Resolution</div>
                    <div>1920x1080</div>
                  </div>
                  <div>
                    <div className="text-gray-500 text-xs mb-1">Bit Depth</div>
                    <div>8-bit</div>
                  </div>
                </div>
                <div>
                  <div className="text-gray-500 text-xs mb-1">Codec</div>
                  <div>H.264 (AVC)</div>
                </div>
                <div>
                  <div className="text-gray-500 text-xs mb-1">File Size</div>
                  <div>842 MB</div>
                </div>
                <div className="pt-3 border-t border-gray-800">
                  <div className="text-gray-500 text-xs mb-2">Proxy Status</div>
                  <div className="flex items-center gap-2">
                    <CheckCircle size={16} className="text-green-500" />
                    <span className="text-green-500">Proxy Active</span>
                  </div>
                  <div className="mt-2 text-xs text-gray-500">
                    ProRes Proxy • 960x540 • 126 MB
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-500 text-sm py-8">
              Select a media item to view details
            </div>
          )}
        </div>
      </div>
    </div>
  );
}