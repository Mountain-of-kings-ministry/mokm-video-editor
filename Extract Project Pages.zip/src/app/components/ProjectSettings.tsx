export function ProjectSettings() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-3xl mx-auto p-8">
        <h1 className="text-2xl font-bold mb-6">Project Settings</h1>

        <div className="space-y-6">
          {/* Timeline Settings */}
          <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
            <h2 className="text-lg font-semibold mb-4">Timeline</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Frame Rate</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option>23.976 fps</option>
                    <option selected>24 fps</option>
                    <option>25 fps</option>
                    <option>29.97 fps</option>
                    <option>30 fps</option>
                    <option>60 fps</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Timebase</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option selected>Drop Frame</option>
                    <option>Non-Drop Frame</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Resolution</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option>3840x2160 (4K UHD)</option>
                    <option selected>1920x1080 (Full HD)</option>
                    <option>1280x720 (HD)</option>
                    <option>Custom</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Pixel Aspect Ratio</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option selected>Square (1.0)</option>
                    <option>NTSC DV (0.9)</option>
                    <option>PAL DV (1.067)</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Color Management */}
          <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
            <h2 className="text-lg font-semibold mb-4">Color Management</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400 block mb-2">Working Color Space</label>
                <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                  <option selected>Rec.709</option>
                  <option>ACES AP0</option>
                  <option>ACES AP1</option>
                  <option>DCI-P3</option>
                  <option>Rec.2020</option>
                  <option>sRGB</option>
                </select>
              </div>

              <div>
                <label className="text-sm text-gray-400 block mb-2">OCIO Config</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    defaultValue="/usr/share/ocio/aces_1.2/config.ocio"
                    className="flex-1 px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500"
                  />
                  <button className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded">Browse</button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Bit Depth</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option selected>8-bit</option>
                    <option>10-bit</option>
                    <option>12-bit</option>
                    <option>16-bit Float</option>
                    <option>32-bit Float</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Display Transform</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option selected>sRGB</option>
                    <option>Rec.709</option>
                    <option>DCI-P3</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Audio Settings */}
          <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
            <h2 className="text-lg font-semibold mb-4">Audio</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Sample Rate</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option>44.1 kHz</option>
                    <option selected>48 kHz</option>
                    <option>96 kHz</option>
                    <option>192 kHz</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Bit Depth</label>
                  <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                    <option>16-bit</option>
                    <option selected>24-bit</option>
                    <option>32-bit Float</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-400 block mb-2">Default Channels</label>
                <select className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500">
                  <option>Mono</option>
                  <option selected>Stereo</option>
                  <option>5.1 Surround</option>
                  <option>7.1 Surround</option>
                </select>
              </div>
            </div>
          </div>

          {/* Project Info */}
          <div className="bg-[#0f0f0f] border border-gray-800 rounded-lg p-6">
            <h2 className="text-lg font-semibold mb-4">Project Information</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400 block mb-2">Project Name</label>
                <input
                  type="text"
                  defaultValue="Untitled Project"
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-sm text-gray-400 block mb-2">Project Location</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    defaultValue="/home/user/projects/video-project"
                    className="flex-1 px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500"
                  />
                  <button className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded">Browse</button>
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-400 block mb-2">Description</label>
                <textarea
                  rows={4}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded focus:outline-none focus:border-blue-500"
                  placeholder="Project description..."
                />
              </div>
            </div>
          </div>

          {/* Save Buttons */}
          <div className="flex justify-end gap-3">
            <button className="px-6 py-2 bg-gray-800 hover:bg-gray-700 rounded">Cancel</button>
            <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded font-medium">Save Settings</button>
          </div>
        </div>
      </div>
    </div>
  );
}